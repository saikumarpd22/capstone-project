package com.edubridge.app1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.app1.model.Customer;
import com.edubridge.app1.model.GasRefill;
import com.edubridge.app1.service.CustomerService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")

public class CustomerController {

	@Autowired
	private CustomerService service;
	
	@PostMapping("/customer")
	public ResponseEntity<?> save(@RequestBody Customer customer){
		Customer newCustomer = service.saveCustomer(customer);
		return new ResponseEntity<>(newCustomer, HttpStatus.CREATED);
	}
	
	@GetMapping("/customer")
	public ResponseEntity<?> getCustomer(){
		List<Customer> customers = service.getCustomers();
		return new ResponseEntity<>(customers, HttpStatus.OK);
	}
	
	
	//http://localhost:8181/myapp/api/customer
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<?> getCustomer(@PathVariable Integer customerId){
	
		Customer customer=service.getCustomer(customerId);
		return new ResponseEntity<>(customer, HttpStatus.OK);
	}
	
	@DeleteMapping("/customer/{customerId}")
	public ResponseEntity<?> delete(@PathVariable Integer customerId){
		
		service.deleteCustomer(customerId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@PutMapping("/customer/{customerId}")
	public ResponseEntity<?> update(@RequestBody Customer customer){
		service.updateCustomer(customer);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	

}

