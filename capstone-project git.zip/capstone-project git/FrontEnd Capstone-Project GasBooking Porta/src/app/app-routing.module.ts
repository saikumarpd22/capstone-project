import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './component/aboutus/aboutus.component';
import { CustomerCreateComponent } from './component/customer-create/customer-create.component';
import { CustomerListComponent } from './component/customer-list/customer-list.component';
import { BookGasComponent } from './component/book-gas/book-gas.component';
import { CustomerEditComponent } from './component/customer-edit/customer-edit.component';

const routes: Routes = [
  {path:'about-us',component:AboutusComponent},
  {path:'customer-create',component:CustomerCreateComponent},
  {path:'customer-list',component:CustomerListComponent},
  {path:'book-gas', component:BookGasComponent},
  {path:'edit/:customerId', component:CustomerEditComponent},
  {path:'book-gas/:customerId', component:BookGasComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
