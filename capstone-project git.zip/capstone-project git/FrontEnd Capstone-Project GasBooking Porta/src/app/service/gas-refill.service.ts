import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GasRefill } from '../model/gasrefill';

@Injectable({
  providedIn: 'root'
})
export class GasRefillService {

  baseUrl="http://localhost:8181/myapp/api/customers{customerRefills{customerId}}";
  constructor(private http: HttpClient) { }

  getGasRefills(){
   return this.http.get<GasRefill[]>(this.baseUrl); 
  }

  createGasRefill(gasrefill:GasRefill){
    return this.http.post<GasRefill>(this.baseUrl,gasrefill)
  }
}
