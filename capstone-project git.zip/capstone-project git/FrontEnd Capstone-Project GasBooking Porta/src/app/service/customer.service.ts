import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  
  baseUrl="http://localhost:8181/myapp/api/customer";
  constructor(private http: HttpClient) { }

  getCustomers(){
   return this.http.get<Customer[]>(this.baseUrl); 
  }

  createCustomer(customer:Customer){
    return this.http.post<Customer>(this.baseUrl,customer)
  }

  deleteCustomer(customerId: Number) {
    return this.http.delete(this.baseUrl+"/"+customerId);
  }

  getCustomer(customerId: number) {
    return this.http.get<Customer>(this.baseUrl+'/'+customerId);
  }

  updateCustomer(customer: Customer, customerId: any) {
    return this.http.put(this.baseUrl+"/"+customerId, customer);
  }

}
