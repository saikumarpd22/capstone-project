export class Customer {
    customerId:number;
    customerName:string;
    customerMail:string;
    customerMobile:number;
    customerCity:string;
    customerState:string;
    customerCountry:string;
    customerPincode:number;
    customerRefills:any;
}
